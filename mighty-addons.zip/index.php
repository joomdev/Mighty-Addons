<?php
// Silence is golden, But my eyes still see
// https://www.youtube.com/watch?v=n03g8nsaBro