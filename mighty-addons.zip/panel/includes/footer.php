        </div>
    </div>

  <div id="proModal" class="modal">
    <div class="modal-content text-center">
      <span class="rocket">🚀</span>
      <h3>To enable this feature, please get a pro version of Mighty Addons.</h3>
      <a href="https://mightythemes.com/products/mighty-addons/" target="_BLANK" class="button ma-btn cs-cta">Get Mighty Addons Pro</a>
    </div>
  </div>

</div>